package com.example.firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
